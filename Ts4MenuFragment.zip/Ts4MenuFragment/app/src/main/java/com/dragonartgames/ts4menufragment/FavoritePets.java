package com.dragonartgames.ts4menufragment;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;

public class FavoritePets extends AppCompatActivity {

    ArrayList<Pet> pets;
    private RecyclerView listPets;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.masoctas_favoritas);

        Toolbar actionBarFavoritePets = (Toolbar) findViewById(R.id.actionBarFavoritePets);
        setSupportActionBar(actionBarFavoritePets);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listPets = (RecyclerView) findViewById(R.id.rvPets);

        LinearLayoutManager linearLManager = new LinearLayoutManager(this);
        linearLManager.setOrientation(LinearLayoutManager.VERTICAL);

        listPets.setLayoutManager(linearLManager);
        initializeListPets();
        initializeAdapterPet();

    }

    public void initializeAdapterPet(){

        Mascota mascota = new Mascota(pets);
        listPets.setAdapter(mascota);

    }

    public void initializeListPets(){

        pets = new ArrayList<Pet>();


        pets.add(new Pet(R.drawable.gato2,"LUNA","2"));
        pets.add(new Pet(R.drawable.perro3,"RUFO","3"));
        pets.add(new Pet(R.drawable.perro4,"REX","1"));
        pets.add(new Pet(R.drawable.gat05,"KIRA","6"));
        pets.add(new Pet(R.drawable.perro3,"BRUNO","9"));


    }
}
