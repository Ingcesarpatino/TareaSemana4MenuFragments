package com.dragonartgames.ts4menufragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;

public class MainFragment extends Fragment {

    ArrayList<Pet> pets;
    private RecyclerView listPets;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View vFragment = inflater.inflate(R.layout.fragment_main, container, false);

        listPets = (RecyclerView) vFragment.findViewById(R.id.rvPets);

        LinearLayoutManager linearLManager = new LinearLayoutManager(getActivity());
        linearLManager.setOrientation(LinearLayoutManager.VERTICAL);

        listPets.setLayoutManager(linearLManager);
        initializeListPets();
        initializeAdapterPet();

        return vFragment;
    }

    public void initializeAdapterPet(){

        Mascota mascota = new Mascota(pets);
        listPets.setAdapter(mascota);

    }

    public void initializeListPets(){

        pets = new ArrayList<Pet>();

        pets.add(new Pet(R.drawable.perro1,"BRUNO","5"));
        pets.add(new Pet(R.drawable.gato2,"LUNA","6"));
        pets.add(new Pet(R.drawable.perro3,"RUFO","1"));
        pets.add(new Pet(R.drawable.perro4,"REX","3"));
        pets.add(new Pet(R.drawable.gat05,"KIRA","0"));
        pets.add(new Pet(R.drawable.perro1,"RUFITO","4"));
        pets.add(new Pet(R.drawable.perro4,"CINTIA","8"));
        pets.add(new Pet(R.drawable.gat05,"KATTY","2"));

    }
}
