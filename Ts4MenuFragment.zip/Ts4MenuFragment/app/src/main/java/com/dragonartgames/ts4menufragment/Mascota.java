package com.dragonartgames.ts4menufragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;

public class Mascota extends RecyclerView.Adapter<Mascota.PetViewHolder>{

    ArrayList<Pet> pets;

    public Mascota(ArrayList<Pet> pets){
        this.pets = pets;
    }

    @NonNull
    @Override
    public PetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.mascota_cardview, parent, false);
        return new PetViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull PetViewHolder petViewHolder, int position) {

        final Pet pet = pets.get(position);
        petViewHolder.ivpetImage.setImageResource(pet.getPetImage());
        petViewHolder.tvpetName.setText(pet.getPetName());
        petViewHolder.tvpetRaiting.setText(pet.getPetRaiting());
        petViewHolder.ibboneWhite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int raiting = 0;
                raiting = Integer.parseInt(pet.getPetRaiting()) + 1;
                pet.setPetRaiting(String.valueOf(raiting));
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return pets.size();
    }

    public static class PetViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivpetImage;
        private TextView tvpetName;
        private TextView tvpetRaiting;
        private ImageButton ibboneWhite;

        public PetViewHolder(@NonNull View itemView) {

            super(itemView);
            ivpetImage      = (ImageView) itemView.findViewById(R.id.ivpetImage);
            tvpetName       = (TextView) itemView.findViewById(R.id.tvpetName);
            tvpetRaiting    = (TextView) itemView.findViewById(R.id.tvpetRaiting);
            ibboneWhite     = (ImageButton) itemView.findViewById(R.id.ibboneWhite);

        }

    }

}
