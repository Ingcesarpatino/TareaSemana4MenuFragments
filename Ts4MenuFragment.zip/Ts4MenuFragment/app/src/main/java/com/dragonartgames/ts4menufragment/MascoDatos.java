package com.dragonartgames.ts4menufragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.ArrayList;

public class MascoDatos extends Fragment {

    ArrayList<DataPet> dataPet;
    private RecyclerView listDataPet;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View vFragmentPetData = inflater.inflate(R.layout.fragment_pet_data, container, false);

        CircularImageView circularImageView = (CircularImageView) vFragmentPetData.findViewById(R.id.cImagePet);
        circularImageView.setCircleColor(R.color.circuler_color);
        circularImageView.setBorderWidth(10f);
        circularImageView.setBorderColor(R.color.circuler_boder);
        circularImageView.setShadowEnable(true);

        listDataPet = (RecyclerView) vFragmentPetData.findViewById(R.id.rvPetData);

        GridLayoutManager gLayoutDataPet = new GridLayoutManager(getContext(), 3);

        listDataPet.setLayoutManager(gLayoutDataPet);
        initializeListDataPet();
        initializaAdapterDataPet();

        return vFragmentPetData;
    }

    public void initializaAdapterDataPet(){
        AdaptadorDatosMascota adapterDataPet = new AdaptadorDatosMascota(dataPet);
        listDataPet.setAdapter(adapterDataPet);
    }

    public void initializeListDataPet() {

        dataPet = new ArrayList<DataPet>();

        dataPet.add(new DataPet(R.drawable.perro1, "4"));
        dataPet.add(new DataPet(R.drawable.perro1, "8"));
        dataPet.add(new DataPet(R.drawable.perro1, "9"));
        dataPet.add(new DataPet(R.drawable.perro1, "5"));
        dataPet.add(new DataPet(R.drawable.perro1, "6"));
        dataPet.add(new DataPet(R.drawable.perro1, "3"));
        dataPet.add(new DataPet(R.drawable.perro1, "10"));
        dataPet.add(new DataPet(R.drawable.perro1, "7"));
        dataPet.add(new DataPet(R.drawable.perro1, "4"));
    }

}
