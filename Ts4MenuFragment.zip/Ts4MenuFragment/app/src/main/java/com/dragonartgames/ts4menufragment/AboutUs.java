package com.dragonartgames.ts4menufragment;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AboutUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_us);

        Toolbar actionBarAbout = (Toolbar) findViewById(R.id.actionBarAbout);
        setSupportActionBar(actionBarAbout);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
