package com.dragonartgames.ts4menufragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;

public class AdaptadorDatosMascota extends RecyclerView.Adapter<AdaptadorDatosMascota.DataPetViewHolder> {

    ArrayList<DataPet> dataPet;

    public AdaptadorDatosMascota(ArrayList<DataPet> dataPet){
        this.dataPet = dataPet;
    }

    @NonNull
    @Override
    public AdaptadorDatosMascota.DataPetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_datamasco, parent, false);
        return new AdaptadorDatosMascota.DataPetViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorDatosMascota.DataPetViewHolder petViewHolder, int position) {

        DataPet pet = dataPet.get(position);
        petViewHolder.ivpetImage.setImageResource(pet.getPetImage());
        petViewHolder.tvpetRaiting.setText(pet.getPetRaiting());

    }

    @Override
    public int getItemCount() {
        return dataPet.size();
    }

    public static class DataPetViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivpetImage;
        private TextView tvpetRaiting;

        public DataPetViewHolder(@NonNull View itemView) {

            super(itemView);
            ivpetImage      = (ImageView) itemView.findViewById(R.id.ivpetImage);
            tvpetRaiting    = (TextView) itemView.findViewById(R.id.tvpetRaiting);

        }

    }
}
