package com.dragonartgames.ts4menufragment;

public class Pet {

    private int petImage;
    private String petName;
    private String petRaiting;

    public Pet(int petImage, String petName, String petRaiting){

        this.petImage = petImage;
        this.petName = petName;
        this.petRaiting = petRaiting;

    }

    public int getPetImage() {
        return petImage;
    }

    public void setPetImage(int petImage) {
        this.petImage = petImage;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetRaiting() {
        return petRaiting;
    }

    public void setPetRaiting(String petRaiting) {
        this.petRaiting = petRaiting;
    }
}
